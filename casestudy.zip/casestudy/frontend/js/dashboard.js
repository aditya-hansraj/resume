document.addEventListener('DOMContentLoaded', function () {
  applyRoleVisibility();
  loadDashboard();
});

async function loadDashboard() {
  var errorEl = document.getElementById('dashboard-error');
  errorEl.classList.add('hidden');

  try {
    var results = await Promise.all([
      apiFetch('/customers?page=0&size=1'),
      apiFetch('/products?page=0&size=1'),
      apiFetch('/products?page=0&size=1&lowStockOnly=true'),
      apiFetch('/challans?page=0&size=1&status=DRAFT'),
      apiFetch('/challans?page=0&size=1&status=CONFIRMED'),
      apiFetch('/challans?page=0&size=1&status=CANCELLED')
    ]);

    document.getElementById('card-customers').textContent = results[0].meta.totalElements;
    document.getElementById('card-products').textContent = results[1].meta.totalElements;
    document.getElementById('card-low-stock').textContent = results[2].meta.totalElements;
    document.getElementById('card-draft-challans').textContent = results[3].meta.totalElements;
    document.getElementById('card-confirmed-challans').textContent = results[4].meta.totalElements;
    document.getElementById('card-cancelled-challans').textContent = results[5].meta.totalElements;
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to load dashboard data';
    errorEl.classList.remove('hidden');
  }
}
