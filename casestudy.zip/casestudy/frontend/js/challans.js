var chState = {
  page: 0,
  size: 10,
  totalPages: 1,
  status: ''
};

var allCustomers = [];
var allProducts = [];

document.addEventListener('DOMContentLoaded', function () {
  applyRoleVisibility();
  loadChallans();

  document.getElementById('status-filter').addEventListener('change', function (e) {
    chState.status = e.target.value;
    chState.page = 0;
    loadChallans();
  });

  document.getElementById('prev-btn').addEventListener('click', function () {
    if (chState.page > 0) { chState.page--; loadChallans(); }
  });

  document.getElementById('next-btn').addEventListener('click', function () {
    if (chState.page + 1 < chState.totalPages) { chState.page++; loadChallans(); }
  });

  document.getElementById('add-challan-btn').addEventListener('click', openChallanModal);
  document.getElementById('challan-cancel-btn').addEventListener('click', closeChallanModal);
  document.getElementById('add-line-btn').addEventListener('click', function () { addLineItemRow(); });
  document.getElementById('challan-form').addEventListener('submit', submitChallanForm);
});

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

async function loadChallans() {
  var errorEl = document.getElementById('list-error');
  errorEl.classList.add('hidden');

  var params = new URLSearchParams();
  params.set('page', chState.page);
  params.set('size', chState.size);
  if (chState.status) params.set('status', chState.status);

  try {
    var res = await apiFetch('/challans?' + params.toString());
    renderChallans(res.data);
    chState.totalPages = res.meta.totalPages || 1;
    document.getElementById('page-info').textContent = 'Page ' + (chState.page + 1) + ' of ' + chState.totalPages;
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to load challans';
    errorEl.classList.remove('hidden');
  }
}

function statusBadgeClass(status) {
  if (status === 'CONFIRMED') return 'badge-green';
  if (status === 'CANCELLED') return 'badge-red';
  return 'badge-grey';
}

function renderChallans(challans) {
  var tbody = document.getElementById('challans-tbody');
  tbody.innerHTML = '';

  challans.forEach(function (c) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + escapeHtml(c.challanNumber) + '</td>' +
      '<td>' + escapeHtml(c.customerName || '') + '</td>' +
      '<td><span class="badge ' + statusBadgeClass(c.status) + '">' + escapeHtml(c.status) + '</span></td>' +
      '<td>' + escapeHtml(c.totalQuantity) + '</td>' +
      '<td>' + escapeHtml(c.createdAt || '') + '</td>' +
      '<td data-roles="ADMIN,SALES"></td>';

    var actionsTd = tr.lastElementChild;

    if (c.status === 'DRAFT') {
      var confirmBtn = document.createElement('button');
      confirmBtn.className = 'btn-small';
      confirmBtn.textContent = 'Confirm';
      confirmBtn.addEventListener('click', function (ev) { ev.stopPropagation(); confirmChallan(c.id); });
      actionsTd.appendChild(confirmBtn);

      var cancelBtn = document.createElement('button');
      cancelBtn.className = 'btn-small btn-danger';
      cancelBtn.style.marginLeft = '6px';
      cancelBtn.textContent = 'Cancel';
      cancelBtn.addEventListener('click', function (ev) { ev.stopPropagation(); cancelChallan(c.id); });
      actionsTd.appendChild(cancelBtn);
    } else if (c.status === 'CONFIRMED') {
      var cancelBtn2 = document.createElement('button');
      cancelBtn2.className = 'btn-small btn-danger';
      cancelBtn2.textContent = 'Cancel';
      cancelBtn2.addEventListener('click', function (ev) { ev.stopPropagation(); cancelChallan(c.id); });
      actionsTd.appendChild(cancelBtn2);
    }

    tbody.appendChild(tr);
  });

  applyRoleVisibility();
}

async function confirmChallan(id) {
  try {
    await apiFetch('/challans/' + id + '/confirm', { method: 'POST' });
    loadChallans();
  } catch (err) {
    alert(err.message || 'Failed to confirm challan');
  }
}

async function cancelChallan(id) {
  if (!confirm('Cancel this challan?')) return;
  try {
    await apiFetch('/challans/' + id + '/cancel', { method: 'POST' });
    loadChallans();
  } catch (err) {
    alert(err.message || 'Failed to cancel challan');
  }
}

async function openChallanModal() {
  document.getElementById('challan-form-error').classList.add('hidden');
  document.getElementById('challan-form').reset();
  document.getElementById('line-items-container').innerHTML = '';

  try {
    var [custRes, prodRes] = await Promise.all([
      apiFetch('/customers?page=0&size=1000'),
      apiFetch('/products?page=0&size=1000')
    ]);
    allCustomers = custRes.data;
    allProducts = prodRes.data;

    var custSelect = document.getElementById('ch-customer');
    custSelect.innerHTML = allCustomers.map(function (c) {
      return '<option value="' + c.id + '">' + escapeHtml(c.name) + '</option>';
    }).join('');

    addLineItemRow();
    document.getElementById('challan-modal-overlay').classList.remove('hidden');
  } catch (err) {
    alert(err.message || 'Failed to load customers/products');
  }
}

function closeChallanModal() {
  document.getElementById('challan-modal-overlay').classList.add('hidden');
}

function addLineItemRow() {
  var container = document.getElementById('line-items-container');
  var row = document.createElement('div');
  row.className = 'line-item-row';

  var productSelect = document.createElement('select');
  productSelect.className = 'line-product';
  productSelect.innerHTML = allProducts.map(function (p) {
    return '<option value="' + p.id + '">' + escapeHtml(p.name) + ' (' + escapeHtml(p.sku) + ')</option>';
  }).join('');

  var qtyInput = document.createElement('input');
  qtyInput.type = 'number';
  qtyInput.min = '1';
  qtyInput.className = 'line-qty';
  qtyInput.placeholder = 'Qty';
  qtyInput.required = true;

  var removeBtn = document.createElement('button');
  removeBtn.type = 'button';
  removeBtn.className = 'btn-small btn-danger';
  removeBtn.textContent = 'Remove';
  removeBtn.addEventListener('click', function () { row.remove(); });

  row.appendChild(productSelect);
  row.appendChild(qtyInput);
  row.appendChild(removeBtn);
  container.appendChild(row);
}

async function submitChallanForm(e) {
  e.preventDefault();
  var errorEl = document.getElementById('challan-form-error');
  errorEl.classList.add('hidden');

  var customerId = document.getElementById('ch-customer').value;
  var rows = document.querySelectorAll('#line-items-container .line-item-row');
  var items = [];
  rows.forEach(function (row) {
    var productId = row.querySelector('.line-product').value;
    var qty = parseInt(row.querySelector('.line-qty').value, 10);
    if (productId && qty > 0) {
      items.push({ productId: productId, quantity: qty });
    }
  });

  if (items.length === 0) {
    errorEl.textContent = 'Add at least one line item.';
    errorEl.classList.remove('hidden');
    return;
  }

  try {
    await apiFetch('/challans', { method: 'POST', body: JSON.stringify({ customerId: customerId, items: items }) });
    closeChallanModal();
    loadChallans();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to create challan';
    errorEl.classList.remove('hidden');
  }
}
