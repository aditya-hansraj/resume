var pState = {
  page: 0,
  size: 10,
  totalPages: 1,
  search: '',
  category: '',
  lowStockOnly: false
};

document.addEventListener('DOMContentLoaded', function () {
  applyRoleVisibility();
  loadProducts();

  document.getElementById('search-input').addEventListener('input', debounce(function (e) {
    pState.search = e.target.value.trim();
    pState.page = 0;
    loadProducts();
  }, 400));

  document.getElementById('category-filter').addEventListener('input', debounce(function (e) {
    pState.category = e.target.value.trim();
    pState.page = 0;
    loadProducts();
  }, 400));

  document.getElementById('low-stock-checkbox').addEventListener('change', function (e) {
    pState.lowStockOnly = e.target.checked;
    pState.page = 0;
    loadProducts();
  });

  document.getElementById('prev-btn').addEventListener('click', function () {
    if (pState.page > 0) { pState.page--; loadProducts(); }
  });

  document.getElementById('next-btn').addEventListener('click', function () {
    if (pState.page + 1 < pState.totalPages) { pState.page++; loadProducts(); }
  });

  document.getElementById('add-product-btn').addEventListener('click', function () {
    openProductModal(null);
  });

  document.getElementById('product-cancel-btn').addEventListener('click', closeProductModal);
  document.getElementById('product-form').addEventListener('submit', submitProductForm);

  document.getElementById('stock-cancel-btn').addEventListener('click', closeStockModal);
  document.getElementById('stock-form').addEventListener('submit', submitStockForm);
});

function debounce(fn, wait) {
  var t;
  return function () {
    var args = arguments;
    clearTimeout(t);
    t = setTimeout(function () { fn.apply(null, args); }, wait);
  };
}

async function loadProducts() {
  var errorEl = document.getElementById('list-error');
  errorEl.classList.add('hidden');

  var params = new URLSearchParams();
  params.set('page', pState.page);
  params.set('size', pState.size);
  if (pState.search) params.set('search', pState.search);
  if (pState.category) params.set('category', pState.category);
  if (pState.lowStockOnly) params.set('lowStockOnly', 'true');

  try {
    var res = await apiFetch('/products?' + params.toString());
    renderProducts(res.data);
    pState.totalPages = res.meta.totalPages || 1;
    document.getElementById('page-info').textContent = 'Page ' + (pState.page + 1) + ' of ' + pState.totalPages;
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to load products';
    errorEl.classList.remove('hidden');
  }
}

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

var productsCache = {};

function renderProducts(products) {
  var tbody = document.getElementById('products-tbody');
  tbody.innerHTML = '';
  productsCache = {};

  products.forEach(function (p) {
    productsCache[p.id] = p;
    var lowStock = p.currentStock <= p.minStockAlert;
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + escapeHtml(p.name) + '</td>' +
      '<td>' + escapeHtml(p.sku) + '</td>' +
      '<td>' + escapeHtml(p.category || '') + '</td>' +
      '<td>' + escapeHtml(p.unitPrice) + '</td>' +
      '<td>' + (lowStock ? '<span class="badge badge-red">' + p.currentStock + '</span>' : p.currentStock) + '</td>' +
      '<td>' + escapeHtml(p.minStockAlert) + '</td>' +
      '<td>' + escapeHtml(p.location || '') + '</td>' +
      '<td data-roles="ADMIN,WAREHOUSE"></td>';

    var actionsTd = tr.lastElementChild;
    var editBtn = document.createElement('button');
    editBtn.className = 'btn-small btn-secondary';
    editBtn.textContent = 'Edit';
    editBtn.addEventListener('click', function (ev) { ev.stopPropagation(); openProductModal(p); });

    var stockBtn = document.createElement('button');
    stockBtn.className = 'btn-small';
    stockBtn.style.marginLeft = '6px';
    stockBtn.textContent = 'Stock Move';
    stockBtn.addEventListener('click', function (ev) { ev.stopPropagation(); openStockModal(p.id); });

    var delBtn = document.createElement('button');
    delBtn.className = 'btn-small btn-danger';
    delBtn.style.marginLeft = '6px';
    delBtn.textContent = 'Delete';
    delBtn.addEventListener('click', function (ev) { ev.stopPropagation(); deleteProduct(p.id); });

    actionsTd.appendChild(editBtn);
    actionsTd.appendChild(stockBtn);
    actionsTd.appendChild(delBtn);

    tbody.appendChild(tr);
  });

  applyRoleVisibility();
}

function openProductModal(product) {
  document.getElementById('product-form-error').classList.add('hidden');
  document.getElementById('product-modal-title').textContent = product ? 'Edit Product' : 'Add Product';
  document.getElementById('p-id').value = product ? product.id : '';
  document.getElementById('p-name').value = product ? product.name : '';
  document.getElementById('p-sku').value = product ? product.sku : '';
  document.getElementById('p-category').value = product ? (product.category || '') : '';
  document.getElementById('p-price').value = product ? product.unitPrice : '';
  document.getElementById('p-stock').value = product ? product.currentStock : 0;
  document.getElementById('p-min-alert').value = product ? product.minStockAlert : 0;
  document.getElementById('p-location').value = product ? (product.location || '') : '';
  document.getElementById('product-modal-overlay').classList.remove('hidden');
}

function closeProductModal() {
  document.getElementById('product-modal-overlay').classList.add('hidden');
}

async function submitProductForm(e) {
  e.preventDefault();
  var errorEl = document.getElementById('product-form-error');
  errorEl.classList.add('hidden');

  var id = document.getElementById('p-id').value;
  var payload = {
    name: document.getElementById('p-name').value.trim(),
    sku: document.getElementById('p-sku').value.trim(),
    category: document.getElementById('p-category').value.trim(),
    unitPrice: parseFloat(document.getElementById('p-price').value),
    currentStock: parseInt(document.getElementById('p-stock').value, 10),
    minStockAlert: parseInt(document.getElementById('p-min-alert').value, 10),
    location: document.getElementById('p-location').value.trim()
  };

  try {
    if (id) {
      await apiFetch('/products/' + id, { method: 'PUT', body: JSON.stringify(payload) });
    } else {
      await apiFetch('/products', { method: 'POST', body: JSON.stringify(payload) });
    }
    closeProductModal();
    loadProducts();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to save product';
    errorEl.classList.remove('hidden');
  }
}

async function deleteProduct(id) {
  if (!confirm('Delete this product?')) return;
  try {
    await apiFetch('/products/' + id, { method: 'DELETE' });
    loadProducts();
  } catch (err) {
    alert(err.message || 'Failed to delete product');
  }
}

function openStockModal(productId) {
  document.getElementById('stock-form-error').classList.add('hidden');
  document.getElementById('s-product-id').value = productId;
  document.getElementById('s-type').value = 'IN';
  document.getElementById('s-quantity').value = '';
  document.getElementById('s-reason').value = '';
  document.getElementById('stock-modal-overlay').classList.remove('hidden');
}

function closeStockModal() {
  document.getElementById('stock-modal-overlay').classList.add('hidden');
}

async function submitStockForm(e) {
  e.preventDefault();
  var errorEl = document.getElementById('stock-form-error');
  errorEl.classList.add('hidden');

  var productId = document.getElementById('s-product-id').value;
  var payload = {
    quantity: parseInt(document.getElementById('s-quantity').value, 10),
    movementType: document.getElementById('s-type').value,
    reason: document.getElementById('s-reason').value.trim()
  };

  try {
    await apiFetch('/products/' + productId + '/stock-movements', { method: 'POST', body: JSON.stringify(payload) });
    closeStockModal();
    loadProducts();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to record stock movement';
    errorEl.classList.remove('hidden');
  }
}
