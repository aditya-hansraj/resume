var customerId = new URLSearchParams(window.location.search).get('id');

document.addEventListener('DOMContentLoaded', function () {
  applyRoleVisibility();

  if (!customerId) {
    showDetailError('No customer id provided.');
    return;
  }

  loadCustomer();

  document.getElementById('edit-btn').addEventListener('click', enableEdit);
  document.getElementById('cancel-edit-btn').addEventListener('click', function () {
    disableEdit();
    loadCustomer();
  });
  document.getElementById('customer-detail-form').addEventListener('submit', saveCustomer);
  document.getElementById('followup-form').addEventListener('submit', addFollowup);
});

function showDetailError(msg) {
  var el = document.getElementById('detail-error');
  el.textContent = msg;
  el.classList.remove('hidden');
}

async function loadCustomer() {
  document.getElementById('detail-error').classList.add('hidden');
  try {
    var res = await apiFetch('/customers/' + customerId);
    var c = res.data;
    document.getElementById('d-name').value = c.name || '';
    document.getElementById('d-mobile').value = c.mobile || '';
    document.getElementById('d-email').value = c.email || '';
    document.getElementById('d-business').value = c.businessName || '';
    document.getElementById('d-gst').value = c.gstNumber || '';
    document.getElementById('d-type').value = c.customerType || 'RETAIL';
    document.getElementById('d-address').value = c.address || '';
    document.getElementById('d-status').value = c.status || 'LEAD';
    document.getElementById('d-followup').value = c.followUpDate || '';
    document.getElementById('d-notes').value = c.notes || '';

    renderFollowups(c.followups || []);
  } catch (err) {
    showDetailError(err.message || 'Failed to load customer');
  }
}

function renderFollowups(followups) {
  var tbody = document.getElementById('followups-tbody');
  tbody.innerHTML = '';
  followups.forEach(function (f) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + escapeHtml(f.followUpDate || '') + '</td>' +
      '<td>' + escapeHtml(f.note || '') + '</td>' +
      '<td>' + escapeHtml(f.createdByName || '') + '</td>' +
      '<td>' + escapeHtml(f.createdAt || '') + '</td>';
    tbody.appendChild(tr);
  });
}

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function enableEdit() {
  ['d-name', 'd-mobile', 'd-email', 'd-business', 'd-gst', 'd-type', 'd-address', 'd-status', 'd-followup', 'd-notes']
    .forEach(function (id) { document.getElementById(id).disabled = false; });
  document.getElementById('edit-btn').classList.add('hidden');
  document.getElementById('save-btn').classList.remove('hidden');
  document.getElementById('cancel-edit-btn').classList.remove('hidden');
}

function disableEdit() {
  ['d-name', 'd-mobile', 'd-email', 'd-business', 'd-gst', 'd-type', 'd-address', 'd-status', 'd-followup', 'd-notes']
    .forEach(function (id) { document.getElementById(id).disabled = true; });
  document.getElementById('edit-btn').classList.remove('hidden');
  document.getElementById('save-btn').classList.add('hidden');
  document.getElementById('cancel-edit-btn').classList.add('hidden');
}

async function saveCustomer(e) {
  e.preventDefault();
  var errorEl = document.getElementById('detail-form-error');
  errorEl.classList.add('hidden');

  var payload = {
    name: document.getElementById('d-name').value.trim(),
    mobile: document.getElementById('d-mobile').value.trim(),
    email: document.getElementById('d-email').value.trim(),
    businessName: document.getElementById('d-business').value.trim(),
    gstNumber: document.getElementById('d-gst').value.trim(),
    customerType: document.getElementById('d-type').value,
    address: document.getElementById('d-address').value.trim(),
    status: document.getElementById('d-status').value,
    followUpDate: document.getElementById('d-followup').value || null,
    notes: document.getElementById('d-notes').value.trim()
  };

  try {
    await apiFetch('/customers/' + customerId, { method: 'PUT', body: JSON.stringify(payload) });
    disableEdit();
    loadCustomer();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to save customer';
    errorEl.classList.remove('hidden');
  }
}

async function addFollowup(e) {
  e.preventDefault();
  var errorEl = document.getElementById('followup-error');
  errorEl.classList.add('hidden');

  var payload = {
    note: document.getElementById('fu-note').value.trim(),
    followUpDate: document.getElementById('fu-date').value
  };

  try {
    await apiFetch('/customers/' + customerId + '/followups', { method: 'POST', body: JSON.stringify(payload) });
    document.getElementById('followup-form').reset();
    loadCustomer();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to add follow-up';
    errorEl.classList.remove('hidden');
  }
}
