// Small fetch wrapper for the ERP API. No modules; functions attach to global scope.
var API_BASE = 'http://localhost:8081/api';

async function apiFetch(path, options) {
  options = options || {};
  var headers = options.headers ? Object.assign({}, options.headers) : {};

  var token = localStorage.getItem('erp_token');
  if (token) {
    headers['Authorization'] = 'Bearer ' + token;
  }
  if (options.body && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }

  var response;
  try {
    response = await fetch(API_BASE + path, Object.assign({}, options, { headers: headers }));
  } catch (networkErr) {
    throw new Error('Network error: could not reach server.');
  }

  if (response.status === 401) {
    localStorage.removeItem('erp_token');
    localStorage.removeItem('erp_user');
    window.location.href = 'login.html';
    throw new Error('Unauthorized');
  }

  var body = null;
  try {
    body = await response.json();
  } catch (parseErr) {
    body = null;
  }

  if (!response.ok || !body || body.success === false) {
    var msg = (body && body.message) ? body.message : ('Request failed with status ' + response.status);
    var err = new Error(msg);
    err.details = body ? body.details : null;
    throw err;
  }

  return body;
}
