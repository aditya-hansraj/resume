// Runs immediately: guards every page except login.html.
(function () {
  var isLoginPage = window.location.pathname.indexOf('login.html') !== -1;
  if (isLoginPage) return;

  var token = localStorage.getItem('erp_token');
  if (!token) {
    window.location.href = 'login.html';
  }
})();

function getCurrentUser() {
  var raw = localStorage.getItem('erp_user');
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch (e) {
    return null;
  }
}

function applyRoleVisibility() {
  var user = getCurrentUser();
  var role = user ? user.role : null;

  var els = document.querySelectorAll('[data-roles]');
  els.forEach(function (el) {
    var allowed = el.getAttribute('data-roles').split(',').map(function (r) { return r.trim(); });
    if (role && allowed.indexOf(role) !== -1) {
      el.classList.remove('hidden');
    } else {
      el.classList.add('hidden');
    }
  });

  var nameEls = document.querySelectorAll('[data-user-name]');
  nameEls.forEach(function (el) { el.textContent = user ? user.name : ''; });

  var roleEls = document.querySelectorAll('[data-user-role]');
  roleEls.forEach(function (el) { el.textContent = user ? user.role : ''; });
}

function logout() {
  localStorage.removeItem('erp_token');
  localStorage.removeItem('erp_user');
  window.location.href = 'login.html';
}
