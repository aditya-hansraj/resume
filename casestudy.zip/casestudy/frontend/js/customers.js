var state = {
  page: 0,
  size: 10,
  totalPages: 1,
  search: '',
  status: '',
  customerType: ''
};

document.addEventListener('DOMContentLoaded', function () {
  applyRoleVisibility();
  loadCustomers();

  document.getElementById('search-input').addEventListener('input', debounce(function (e) {
    state.search = e.target.value.trim();
    state.page = 0;
    loadCustomers();
  }, 400));

  document.getElementById('status-filter').addEventListener('change', function (e) {
    state.status = e.target.value;
    state.page = 0;
    loadCustomers();
  });

  document.getElementById('type-filter').addEventListener('change', function (e) {
    state.customerType = e.target.value;
    state.page = 0;
    loadCustomers();
  });

  document.getElementById('prev-btn').addEventListener('click', function () {
    if (state.page > 0) { state.page--; loadCustomers(); }
  });

  document.getElementById('next-btn').addEventListener('click', function () {
    if (state.page + 1 < state.totalPages) { state.page++; loadCustomers(); }
  });

  document.getElementById('add-customer-btn').addEventListener('click', function () {
    openCustomerModal(null);
  });

  document.getElementById('customer-cancel-btn').addEventListener('click', closeCustomerModal);

  document.getElementById('customer-form').addEventListener('submit', submitCustomerForm);
});

function debounce(fn, wait) {
  var t;
  return function () {
    var args = arguments;
    clearTimeout(t);
    t = setTimeout(function () { fn.apply(null, args); }, wait);
  };
}

async function loadCustomers() {
  var errorEl = document.getElementById('list-error');
  errorEl.classList.add('hidden');

  var params = new URLSearchParams();
  params.set('page', state.page);
  params.set('size', state.size);
  if (state.search) params.set('search', state.search);
  if (state.status) params.set('status', state.status);
  if (state.customerType) params.set('customerType', state.customerType);

  try {
    var res = await apiFetch('/customers?' + params.toString());
    renderCustomers(res.data);
    state.totalPages = res.meta.totalPages || 1;
    document.getElementById('page-info').textContent = 'Page ' + (state.page + 1) + ' of ' + state.totalPages;
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to load customers';
    errorEl.classList.remove('hidden');
  }
}

function statusBadgeClass(status) {
  if (status === 'ACTIVE') return 'badge-green';
  if (status === 'LEAD') return 'badge-blue';
  return 'badge-grey';
}

function renderCustomers(customers) {
  var tbody = document.getElementById('customers-tbody');
  tbody.innerHTML = '';

  customers.forEach(function (c) {
    var tr = document.createElement('tr');
    tr.innerHTML =
      '<td>' + escapeHtml(c.name) + '</td>' +
      '<td>' + escapeHtml(c.mobile || '') + '</td>' +
      '<td>' + escapeHtml(c.businessName || '') + '</td>' +
      '<td>' + escapeHtml(c.customerType || '') + '</td>' +
      '<td><span class="badge ' + statusBadgeClass(c.status) + '">' + escapeHtml(c.status || '') + '</span></td>' +
      '<td>' + escapeHtml(c.followUpDate || '') + '</td>';
    tr.addEventListener('click', function () {
      window.location.href = 'customer-detail.html?id=' + c.id;
    });
    tbody.appendChild(tr);
  });
}

function escapeHtml(str) {
  var div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function openCustomerModal(customer) {
  document.getElementById('customer-form-error').classList.add('hidden');
  document.getElementById('customer-modal-title').textContent = customer ? 'Edit Customer' : 'Add Customer';
  document.getElementById('customer-id').value = customer ? customer.id : '';
  document.getElementById('c-name').value = customer ? customer.name : '';
  document.getElementById('c-mobile').value = customer ? customer.mobile : '';
  document.getElementById('c-email').value = customer ? (customer.email || '') : '';
  document.getElementById('c-business').value = customer ? (customer.businessName || '') : '';
  document.getElementById('c-gst').value = customer ? (customer.gstNumber || '') : '';
  document.getElementById('c-type').value = customer ? (customer.customerType || 'RETAIL') : 'RETAIL';
  document.getElementById('c-address').value = customer ? (customer.address || '') : '';
  document.getElementById('c-status').value = customer ? (customer.status || 'LEAD') : 'LEAD';
  document.getElementById('c-followup').value = customer ? (customer.followUpDate || '') : '';
  document.getElementById('c-notes').value = customer ? (customer.notes || '') : '';
  document.getElementById('customer-modal-overlay').classList.remove('hidden');
}

function closeCustomerModal() {
  document.getElementById('customer-modal-overlay').classList.add('hidden');
}

async function submitCustomerForm(e) {
  e.preventDefault();
  var errorEl = document.getElementById('customer-form-error');
  errorEl.classList.add('hidden');

  var id = document.getElementById('customer-id').value;
  var payload = {
    name: document.getElementById('c-name').value.trim(),
    mobile: document.getElementById('c-mobile').value.trim(),
    email: document.getElementById('c-email').value.trim(),
    businessName: document.getElementById('c-business').value.trim(),
    gstNumber: document.getElementById('c-gst').value.trim(),
    customerType: document.getElementById('c-type').value,
    address: document.getElementById('c-address').value.trim(),
    status: document.getElementById('c-status').value,
    followUpDate: document.getElementById('c-followup').value || null,
    notes: document.getElementById('c-notes').value.trim()
  };

  try {
    if (id) {
      await apiFetch('/customers/' + id, { method: 'PUT', body: JSON.stringify(payload) });
    } else {
      await apiFetch('/customers', { method: 'POST', body: JSON.stringify(payload) });
    }
    closeCustomerModal();
    loadCustomers();
  } catch (err) {
    errorEl.textContent = err.message || 'Failed to save customer';
    errorEl.classList.remove('hidden');
  }
}
