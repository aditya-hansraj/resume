document.getElementById('login-form').addEventListener('submit', async function (e) {
  e.preventDefault();
  var errorEl = document.getElementById('login-error');
  errorEl.classList.add('hidden');

  var email = document.getElementById('email').value.trim();
  var password = document.getElementById('password').value;

  try {
    var res = await apiFetch('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: email, password: password })
    });
    localStorage.setItem('erp_token', res.data.token);
    localStorage.setItem('erp_user', JSON.stringify(res.data.user));
    window.location.href = 'dashboard.html';
  } catch (err) {
    errorEl.textContent = err.message || 'Login failed';
    errorEl.classList.remove('hidden');
  }
});
