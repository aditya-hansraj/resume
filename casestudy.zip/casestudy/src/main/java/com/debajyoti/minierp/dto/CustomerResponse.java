package com.debajyoti.minierp.dto;

import com.debajyoti.minierp.entity.CustomerStatus;
import com.debajyoti.minierp.entity.CustomerType;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public record CustomerResponse(
        Long id,
        String name,
        String mobile,
        String email,
        String businessName,
        String gstNumber,
        CustomerType customerType,
        String address,
        CustomerStatus status,
        LocalDate followUpDate,
        String notes,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        List<FollowupResponse> followups
) {
}
