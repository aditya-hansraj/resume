package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.CustomerFollowup;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CustomerFollowupRepository extends JpaRepository<CustomerFollowup, Long> {
    List<CustomerFollowup> findByCustomerIdOrderByCreatedAtDesc(Long customerId);
}
