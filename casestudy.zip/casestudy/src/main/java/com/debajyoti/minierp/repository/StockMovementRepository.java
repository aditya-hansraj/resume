package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.StockMovement;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
}
