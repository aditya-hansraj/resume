package com.debajyoti.minierp.service;

import com.debajyoti.minierp.dto.CustomerRequest;
import com.debajyoti.minierp.dto.CustomerResponse;
import com.debajyoti.minierp.dto.FollowupRequest;
import com.debajyoti.minierp.dto.FollowupResponse;
import com.debajyoti.minierp.entity.Customer;
import com.debajyoti.minierp.entity.CustomerFollowup;
import com.debajyoti.minierp.entity.CustomerStatus;
import com.debajyoti.minierp.entity.CustomerType;
import com.debajyoti.minierp.entity.User;
import com.debajyoti.minierp.exception.ResourceNotFoundException;
import com.debajyoti.minierp.repository.CustomerFollowupRepository;
import com.debajyoti.minierp.repository.CustomerRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.List;

@Service
public class CustomerService {

    public static final int DEFAULT_PAGE_SIZE = 20;

    private final CustomerRepository customerRepository;
    private final CustomerFollowupRepository followupRepository;

    public CustomerService(CustomerRepository customerRepository, CustomerFollowupRepository followupRepository) {
        this.customerRepository = customerRepository;
        this.followupRepository = followupRepository;
    }

    public Page<CustomerResponse> list(String search, CustomerStatus status, CustomerType type, Pageable pageable) {
        return customerRepository.search(blankToNull(search), status, type, pageable)
                .map(c -> toResponse(c, Collections.emptyList()));
    }

    public CustomerResponse getById(Long id) {
        Customer customer = findEntity(id);
        List<CustomerFollowup> followups = followupRepository.findByCustomerIdOrderByCreatedAtDesc(id);
        return toResponse(customer, followups);
    }

    @Transactional
    public CustomerResponse create(CustomerRequest request) {
        Customer customer = new Customer();
        applyRequest(customer, request);
        customer = customerRepository.save(customer);
        return toResponse(customer, Collections.emptyList());
    }

    @Transactional
    public CustomerResponse update(Long id, CustomerRequest request) {
        Customer customer = findEntity(id);
        applyRequest(customer, request);
        customer = customerRepository.save(customer);
        List<CustomerFollowup> followups = followupRepository.findByCustomerIdOrderByCreatedAtDesc(id);
        return toResponse(customer, followups);
    }

    @Transactional
    public void delete(Long id) {
        Customer customer = findEntity(id);
        customerRepository.delete(customer);
    }

    @Transactional
    public FollowupResponse addFollowup(Long customerId, FollowupRequest request, User currentUser) {
        Customer customer = findEntity(customerId);
        CustomerFollowup followup = new CustomerFollowup();
        followup.setCustomer(customer);
        followup.setNote(request.note());
        followup.setFollowUpDate(request.followUpDate());
        followup.setCreatedBy(currentUser);
        followup = followupRepository.save(followup);
        return toFollowupResponse(followup);
    }

    private Customer findEntity(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + id));
    }

    private void applyRequest(Customer customer, CustomerRequest request) {
        customer.setName(request.name());
        customer.setMobile(request.mobile());
        customer.setEmail(request.email());
        customer.setBusinessName(request.businessName());
        customer.setGstNumber(request.gstNumber());
        customer.setCustomerType(request.customerType());
        customer.setAddress(request.address());
        customer.setStatus(request.status());
        customer.setFollowUpDate(request.followUpDate());
        customer.setNotes(request.notes());
    }

    private String blankToNull(String value) {
        return (value == null || value.isBlank()) ? null : value;
    }

    private CustomerResponse toResponse(Customer c, List<CustomerFollowup> followups) {
        return new CustomerResponse(
                c.getId(),
                c.getName(),
                c.getMobile(),
                c.getEmail(),
                c.getBusinessName(),
                c.getGstNumber(),
                c.getCustomerType(),
                c.getAddress(),
                c.getStatus(),
                c.getFollowUpDate(),
                c.getNotes(),
                c.getCreatedAt(),
                c.getUpdatedAt(),
                followups.stream().map(this::toFollowupResponse).toList()
        );
    }

    private FollowupResponse toFollowupResponse(CustomerFollowup f) {
        return new FollowupResponse(
                f.getId(),
                f.getNote(),
                f.getFollowUpDate(),
                f.getCreatedBy() != null ? f.getCreatedBy().getName() : null,
                f.getCreatedAt()
        );
    }
}
