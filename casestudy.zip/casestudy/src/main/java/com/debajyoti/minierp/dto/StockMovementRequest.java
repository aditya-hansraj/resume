package com.debajyoti.minierp.dto;

import com.debajyoti.minierp.entity.MovementType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record StockMovementRequest(
        @NotNull @Positive Integer quantity,
        @NotNull MovementType movementType,
        String reason
) {
}
