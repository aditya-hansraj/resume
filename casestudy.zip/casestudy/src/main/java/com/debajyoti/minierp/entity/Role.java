package com.debajyoti.minierp.entity;

public enum Role {
    ADMIN, SALES, WAREHOUSE, ACCOUNTS
}
