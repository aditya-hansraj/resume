package com.debajyoti.minierp.dto;

import com.debajyoti.minierp.entity.CustomerStatus;
import com.debajyoti.minierp.entity.CustomerType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.LocalDate;

public record CustomerRequest(
        @NotBlank String name,
        @NotBlank String mobile,
        String email,
        String businessName,
        String gstNumber,
        @NotNull CustomerType customerType,
        String address,
        @NotNull CustomerStatus status,
        LocalDate followUpDate,
        String notes
) {
}
