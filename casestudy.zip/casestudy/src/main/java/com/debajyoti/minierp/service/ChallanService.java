package com.debajyoti.minierp.service;

import com.debajyoti.minierp.dto.ChallanItemRequest;
import com.debajyoti.minierp.dto.ChallanItemResponse;
import com.debajyoti.minierp.dto.ChallanRequest;
import com.debajyoti.minierp.dto.ChallanResponse;
import com.debajyoti.minierp.entity.Challan;
import com.debajyoti.minierp.entity.ChallanItem;
import com.debajyoti.minierp.entity.ChallanStatus;
import com.debajyoti.minierp.entity.Customer;
import com.debajyoti.minierp.entity.MovementType;
import com.debajyoti.minierp.entity.Product;
import com.debajyoti.minierp.entity.StockMovement;
import com.debajyoti.minierp.entity.User;
import com.debajyoti.minierp.exception.BusinessRuleException;
import com.debajyoti.minierp.exception.ResourceNotFoundException;
import com.debajyoti.minierp.repository.ChallanRepository;
import com.debajyoti.minierp.repository.CustomerRepository;
import com.debajyoti.minierp.repository.ProductRepository;
import com.debajyoti.minierp.repository.StockMovementRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.Year;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ChallanService {

    public static final int DEFAULT_PAGE_SIZE = 20;

    private final ChallanRepository challanRepository;
    private final CustomerRepository customerRepository;
    private final ProductRepository productRepository;
    private final StockMovementRepository stockMovementRepository;
    private final JdbcTemplate jdbcTemplate;

    public ChallanService(ChallanRepository challanRepository,
                           CustomerRepository customerRepository,
                           ProductRepository productRepository,
                           StockMovementRepository stockMovementRepository,
                           JdbcTemplate jdbcTemplate) {
        this.challanRepository = challanRepository;
        this.customerRepository = customerRepository;
        this.productRepository = productRepository;
        this.stockMovementRepository = stockMovementRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    public Page<ChallanResponse> list(Pageable pageable) {
        return challanRepository.findAll(pageable).map(this::toResponse);
    }

    public ChallanResponse getById(Long id) {
        return toResponse(findEntity(id));
    }

    @Transactional
    public ChallanResponse create(ChallanRequest request, User currentUser) {
        Customer customer = customerRepository.findById(request.customerId())
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + request.customerId()));

        List<Long> productIds = request.items().stream().map(ChallanItemRequest::productId).distinct().toList();
        Map<Long, Product> productsById = productRepository.findAllById(productIds).stream()
                .collect(Collectors.toMap(Product::getId, p -> p, (a, b) -> a, LinkedHashMap::new));

        Challan challan = new Challan();
        challan.setCustomer(customer);
        challan.setStatus(ChallanStatus.DRAFT);
        challan.setCreatedBy(currentUser);
        challan.setChallanNumber(nextChallanNumber());

        int totalQuantity = 0;
        List<ChallanItem> items = new ArrayList<>();
        for (ChallanItemRequest itemRequest : request.items()) {
            Product product = productsById.get(itemRequest.productId());
            if (product == null) {
                throw new ResourceNotFoundException("Product not found with id " + itemRequest.productId());
            }
            ChallanItem item = new ChallanItem();
            item.setChallan(challan);
            item.setProduct(product);
            item.setProductNameSnapshot(product.getName());
            item.setSkuSnapshot(product.getSku());
            item.setUnitPriceSnapshot(product.getUnitPrice());
            item.setQuantity(itemRequest.quantity());
            items.add(item);
            totalQuantity += itemRequest.quantity();
        }
        challan.setItems(items);
        challan.setTotalQuantity(totalQuantity);

        challan = challanRepository.save(challan);
        return toResponse(challan);
    }

    // Generates the next challan number for the current year using an atomic
    // upsert-based counter instead of COUNT(*) on the challans table. COUNT(*)
    // is race-prone: two concurrent transactions could both read the same count
    // before either commits, producing duplicate challan numbers. The upsert
    // below relies on the row-level lock MySQL takes for INSERT ... ON DUPLICATE
    // KEY UPDATE, making the increment atomic across concurrent transactions.
    private String nextChallanNumber() {
        int year = Year.now().getValue();
        jdbcTemplate.update(
                "INSERT INTO challan_counter (year, last_value) VALUES (?, LAST_INSERT_ID(1)) " +
                        "ON DUPLICATE KEY UPDATE last_value = LAST_INSERT_ID(last_value + 1)",
                year
        );
        Long counter = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        return String.format("CH-%d-%06d", year, counter);
    }

    @Transactional
    public ChallanResponse confirm(Long id) {
        Challan challan = challanRepository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("Challan not found with id " + id));

        if (challan.getStatus() != ChallanStatus.DRAFT) {
            throw new BusinessRuleException("Only DRAFT challans can be confirmed (current status: " + challan.getStatus() + ")");
        }

        Map<Long, Integer> requiredByProduct = aggregateQuantityByProduct(challan.getItems());

        // Lock all distinct products in ascending id order (single query) so that
        // concurrent confirmations touching overlapping product sets always
        // acquire locks in the same global order, avoiding deadlocks.
        List<Long> productIds = new ArrayList<>(requiredByProduct.keySet());
        productIds.sort(Long::compareTo);
        List<Product> lockedProducts = productRepository.findAllByIdForUpdateOrderByIdAsc(productIds);
        Map<Long, Product> productsById = lockedProducts.stream()
                .collect(Collectors.toMap(Product::getId, p -> p));

        List<String> shortages = new ArrayList<>();
        for (Map.Entry<Long, Integer> entry : requiredByProduct.entrySet()) {
            Product product = productsById.get(entry.getKey());
            int required = entry.getValue();
            if (product.getCurrentStock() < required) {
                shortages.add(product.getName() + " (need " + required + ", have " + product.getCurrentStock() + ")");
            }
        }
        if (!shortages.isEmpty()) {
            throw new BusinessRuleException("Insufficient stock for: " + String.join(", ", shortages));
        }

        for (Map.Entry<Long, Integer> entry : requiredByProduct.entrySet()) {
            Product product = productsById.get(entry.getKey());
            int required = entry.getValue();
            product.setCurrentStock(product.getCurrentStock() - required);
            productRepository.save(product);

            StockMovement movement = new StockMovement();
            movement.setProduct(product);
            movement.setQuantity(required);
            movement.setMovementType(MovementType.OUT);
            movement.setReason("Challan " + challan.getChallanNumber() + " confirmed");
            movement.setCreatedBy(challan.getCreatedBy());
            stockMovementRepository.save(movement);
        }

        challan.setStatus(ChallanStatus.CONFIRMED);
        challan.setUpdatedAt(LocalDateTime.now());
        challan = challanRepository.save(challan);
        return toResponse(challan);
    }

    @Transactional
    public ChallanResponse cancel(Long id) {
        Challan challan = challanRepository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("Challan not found with id " + id));

        if (challan.getStatus() == ChallanStatus.CANCELLED) {
            throw new BusinessRuleException("Challan is already cancelled");
        }

        if (challan.getStatus() == ChallanStatus.DRAFT) {
            challan.setStatus(ChallanStatus.CANCELLED);
            challan = challanRepository.save(challan);
            return toResponse(challan);
        }

        // CONFIRMED -> CANCELLED: reverse the stock decrement made at confirm time.
        Map<Long, Integer> quantityByProduct = aggregateQuantityByProduct(challan.getItems());
        List<Long> productIds = new ArrayList<>(quantityByProduct.keySet());
        productIds.sort(Long::compareTo);
        List<Product> lockedProducts = productRepository.findAllByIdForUpdateOrderByIdAsc(productIds);
        Map<Long, Product> productsById = lockedProducts.stream()
                .collect(Collectors.toMap(Product::getId, p -> p));

        for (Map.Entry<Long, Integer> entry : quantityByProduct.entrySet()) {
            Product product = productsById.get(entry.getKey());
            int quantity = entry.getValue();
            product.setCurrentStock(product.getCurrentStock() + quantity);
            productRepository.save(product);

            StockMovement movement = new StockMovement();
            movement.setProduct(product);
            movement.setQuantity(quantity);
            movement.setMovementType(MovementType.IN);
            movement.setReason("Challan " + challan.getChallanNumber() + " cancelled - stock reversed");
            movement.setCreatedBy(challan.getCreatedBy());
            stockMovementRepository.save(movement);
        }

        challan.setStatus(ChallanStatus.CANCELLED);
        challan = challanRepository.save(challan);
        return toResponse(challan);
    }

    private Map<Long, Integer> aggregateQuantityByProduct(List<ChallanItem> items) {
        Map<Long, Integer> map = new LinkedHashMap<>();
        for (ChallanItem item : items) {
            map.merge(item.getProduct().getId(), item.getQuantity(), Integer::sum);
        }
        return map;
    }

    private Challan findEntity(Long id) {
        return challanRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Challan not found with id " + id));
    }

    private ChallanResponse toResponse(Challan c) {
        List<ChallanItemResponse> items = c.getItems().stream()
                .map(i -> new ChallanItemResponse(
                        i.getProduct().getId(),
                        i.getProductNameSnapshot(),
                        i.getSkuSnapshot(),
                        i.getUnitPriceSnapshot(),
                        i.getQuantity()))
                .toList();
        return new ChallanResponse(
                c.getId(),
                c.getChallanNumber(),
                c.getCustomer().getId(),
                c.getCustomer().getName(),
                c.getStatus(),
                c.getTotalQuantity(),
                items,
                c.getCreatedBy() != null ? c.getCreatedBy().getName() : null,
                c.getCreatedAt(),
                c.getUpdatedAt()
        );
    }
}
