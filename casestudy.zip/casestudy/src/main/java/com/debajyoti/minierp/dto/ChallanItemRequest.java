package com.debajyoti.minierp.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

public record ChallanItemRequest(
        @NotNull Long productId,
        @NotNull @Positive Integer quantity
) {
}
