package com.debajyoti.minierp.entity;

public enum ChallanStatus {
    DRAFT, CONFIRMED, CANCELLED
}
