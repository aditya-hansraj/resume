package com.debajyoti.minierp.dto;

import com.debajyoti.minierp.entity.MovementType;

import java.time.LocalDateTime;

public record StockMovementResponse(
        Long id,
        Long productId,
        String productName,
        Integer quantity,
        MovementType movementType,
        String reason,
        String createdByName,
        LocalDateTime createdAt
) {
}
