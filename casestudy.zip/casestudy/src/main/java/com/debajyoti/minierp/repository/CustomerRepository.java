package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.Customer;
import com.debajyoti.minierp.entity.CustomerStatus;
import com.debajyoti.minierp.entity.CustomerType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface CustomerRepository extends JpaRepository<Customer, Long> {

    @Query("select c from Customer c where " +
            "(:search is null or " +
            "  lower(c.name) like lower(concat('%', :search, '%')) or " +
            "  c.mobile like concat('%', :search, '%') or " +
            "  lower(c.businessName) like lower(concat('%', :search, '%'))) " +
            "and (:status is null or c.status = :status) " +
            "and (:type is null or c.customerType = :type)")
    Page<Customer> search(@Param("search") String search,
                           @Param("status") CustomerStatus status,
                           @Param("type") CustomerType type,
                           Pageable pageable);
}
