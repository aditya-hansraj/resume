package com.debajyoti.minierp.service;

import com.debajyoti.minierp.dto.ProductRequest;
import com.debajyoti.minierp.dto.ProductResponse;
import com.debajyoti.minierp.dto.StockMovementRequest;
import com.debajyoti.minierp.dto.StockMovementResponse;
import com.debajyoti.minierp.entity.MovementType;
import com.debajyoti.minierp.entity.Product;
import com.debajyoti.minierp.entity.StockMovement;
import com.debajyoti.minierp.entity.User;
import com.debajyoti.minierp.exception.BusinessRuleException;
import com.debajyoti.minierp.exception.ResourceNotFoundException;
import com.debajyoti.minierp.repository.ProductRepository;
import com.debajyoti.minierp.repository.StockMovementRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class ProductService {

    public static final int DEFAULT_PAGE_SIZE = 20;

    private final ProductRepository productRepository;
    private final StockMovementRepository stockMovementRepository;

    public ProductService(ProductRepository productRepository, StockMovementRepository stockMovementRepository) {
        this.productRepository = productRepository;
        this.stockMovementRepository = stockMovementRepository;
    }

    public Page<ProductResponse> list(String search, String category, boolean lowStockOnly, Pageable pageable) {
        return productRepository.search(blankToNull(search), blankToNull(category), lowStockOnly, pageable)
                .map(this::toResponse);
    }

    public ProductResponse getById(Long id) {
        return toResponse(findEntity(id));
    }

    @Transactional
    public ProductResponse create(ProductRequest request) {
        if (productRepository.existsBySku(request.sku())) {
            throw new BusinessRuleException("A product with SKU '" + request.sku() + "' already exists");
        }
        Product product = new Product();
        applyRequest(product, request);
        product = productRepository.save(product);
        return toResponse(product);
    }

    @Transactional
    public ProductResponse update(Long id, ProductRequest request) {
        Product product = findEntity(id);
        if (!product.getSku().equals(request.sku()) && productRepository.existsBySku(request.sku())) {
            throw new BusinessRuleException("A product with SKU '" + request.sku() + "' already exists");
        }
        // current_stock is intentionally not overwritten here: it must only change
        // via addStockMovement(), which keeps stock_movements as the source of truth.
        applyRequestExceptStock(product, request);
        product = productRepository.save(product);
        return toResponse(product);
    }

    @Transactional
    public void delete(Long id) {
        Product product = findEntity(id);
        productRepository.delete(product);
    }

    // Single transactional method: inserts the stock movement record and updates
    // the product's current_stock atomically so the two never drift apart.
    @Transactional
    public StockMovementResponse addStockMovement(Long productId, StockMovementRequest request, User currentUser) {
        Product product = findEntity(productId);

        int delta = request.movementType() == MovementType.IN ? request.quantity() : -request.quantity();
        int newStock = product.getCurrentStock() + delta;
        if (newStock < 0) {
            int shortfall = -newStock;
            throw new BusinessRuleException("Insufficient stock for product '" + product.getName() +
                    "': short by " + shortfall + " unit(s)");
        }
        product.setCurrentStock(newStock);
        productRepository.save(product);

        StockMovement movement = new StockMovement();
        movement.setProduct(product);
        movement.setQuantity(request.quantity());
        movement.setMovementType(request.movementType());
        movement.setReason(request.reason());
        movement.setCreatedBy(currentUser);
        movement = stockMovementRepository.save(movement);

        return toMovementResponse(movement);
    }

    private Product findEntity(Long id) {
        return productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id " + id));
    }

    private void applyRequest(Product product, ProductRequest request) {
        applyRequestExceptStock(product, request);
        product.setCurrentStock(request.currentStock());
    }

    private void applyRequestExceptStock(Product product, ProductRequest request) {
        product.setName(request.name());
        product.setSku(request.sku());
        product.setCategory(request.category());
        product.setUnitPrice(request.unitPrice());
        product.setMinStockAlert(request.minStockAlert());
        product.setLocation(request.location());
    }

    private String blankToNull(String value) {
        return (value == null || value.isBlank()) ? null : value;
    }

    private ProductResponse toResponse(Product p) {
        return new ProductResponse(
                p.getId(), p.getName(), p.getSku(), p.getCategory(), p.getUnitPrice(),
                p.getCurrentStock(), p.getMinStockAlert(), p.getLocation(),
                p.getCreatedAt(), p.getUpdatedAt()
        );
    }

    private StockMovementResponse toMovementResponse(StockMovement m) {
        return new StockMovementResponse(
                m.getId(), m.getProduct().getId(), m.getProduct().getName(),
                m.getQuantity(), m.getMovementType(), m.getReason(),
                m.getCreatedBy() != null ? m.getCreatedBy().getName() : null,
                m.getCreatedAt()
        );
    }
}
