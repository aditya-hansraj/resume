package com.debajyoti.minierp.entity;

public enum CustomerStatus {
    LEAD, ACTIVE, INACTIVE
}
