package com.debajyoti.minierp.controller;

import com.debajyoti.minierp.dto.ApiResponse;
import com.debajyoti.minierp.dto.CustomerRequest;
import com.debajyoti.minierp.dto.CustomerResponse;
import com.debajyoti.minierp.dto.FollowupRequest;
import com.debajyoti.minierp.dto.FollowupResponse;
import com.debajyoti.minierp.dto.PageMeta;
import com.debajyoti.minierp.entity.CustomerStatus;
import com.debajyoti.minierp.entity.CustomerType;
import com.debajyoti.minierp.security.UserPrincipal;
import com.debajyoti.minierp.service.CustomerService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    private final CustomerService customerService;

    public CustomerController(CustomerService customerService) {
        this.customerService = customerService;
    }

    @GetMapping
    public ApiResponse<?> list(@RequestParam(required = false) String search,
                                @RequestParam(required = false) CustomerStatus status,
                                @RequestParam(required = false) CustomerType type,
                                @RequestParam(defaultValue = "0") int page,
                                @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<CustomerResponse> result = customerService.list(search, status, type, pageable);
        PageMeta meta = new PageMeta(result.getNumber(), result.getSize(), result.getTotalElements(), result.getTotalPages());
        return ApiResponse.ok(result.getContent(), meta);
    }

    @GetMapping("/{id}")
    public ApiResponse<CustomerResponse> getById(@PathVariable Long id) {
        return ApiResponse.ok(customerService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<CustomerResponse> create(@Valid @RequestBody CustomerRequest request) {
        return ApiResponse.ok(customerService.create(request));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<CustomerResponse> update(@PathVariable Long id, @Valid @RequestBody CustomerRequest request) {
        return ApiResponse.ok(customerService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<Void> delete(@PathVariable Long id) {
        customerService.delete(id);
        return ApiResponse.ok(null);
    }

    @PostMapping("/{id}/followups")
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<FollowupResponse> addFollowup(@PathVariable Long id,
                                                       @Valid @RequestBody FollowupRequest request,
                                                       @AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(customerService.addFollowup(id, request, principal.getUser()));
    }
}
