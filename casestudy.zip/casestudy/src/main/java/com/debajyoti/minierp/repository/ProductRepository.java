package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.Product;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, Long> {

    Optional<Product> findBySku(String sku);

    boolean existsBySku(String sku);

    @Query("select p from Product p where " +
            "(:search is null or " +
            "  lower(p.name) like lower(concat('%', :search, '%')) or " +
            "  lower(p.sku) like lower(concat('%', :search, '%'))) " +
            "and (:category is null or p.category = :category) " +
            "and (:lowStockOnly = false or p.currentStock <= p.minStockAlert)")
    Page<Product> search(@Param("search") String search,
                          @Param("category") String category,
                          @Param("lowStockOnly") boolean lowStockOnly,
                          Pageable pageable);

    // Pessimistic write lock on the products involved in a challan confirmation,
    // acquired in ascending id order across all rows in a single query to avoid
    // deadlocks between concurrent challan confirmations that share products.
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select p from Product p where p.id in :ids order by p.id asc")
    List<Product> findAllByIdForUpdateOrderByIdAsc(@Param("ids") List<Long> ids);
}
