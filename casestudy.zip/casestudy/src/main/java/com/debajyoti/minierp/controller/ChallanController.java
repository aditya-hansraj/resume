package com.debajyoti.minierp.controller;

import com.debajyoti.minierp.dto.ApiResponse;
import com.debajyoti.minierp.dto.ChallanRequest;
import com.debajyoti.minierp.dto.ChallanResponse;
import com.debajyoti.minierp.dto.PageMeta;
import com.debajyoti.minierp.security.UserPrincipal;
import com.debajyoti.minierp.service.ChallanService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

// GET endpoints have no extra role restriction beyond "authenticated" (enforced
// globally by SecurityConfig): WAREHOUSE needs to see CONFIRMED challans to know
// what to physically ship, and ACCOUNTS needs visibility into all challans for
// billing/reconciliation. Only the write operations (create/confirm/cancel) are
// restricted to ADMIN/SALES, who own the sales workflow.
@RestController
@RequestMapping("/api/challans")
public class ChallanController {

    private final ChallanService challanService;

    public ChallanController(ChallanService challanService) {
        this.challanService = challanService;
    }

    @GetMapping
    public ApiResponse<?> list(@RequestParam(defaultValue = "0") int page,
                                @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<ChallanResponse> result = challanService.list(pageable);
        PageMeta meta = new PageMeta(result.getNumber(), result.getSize(), result.getTotalElements(), result.getTotalPages());
        return ApiResponse.ok(result.getContent(), meta);
    }

    @GetMapping("/{id}")
    public ApiResponse<ChallanResponse> getById(@PathVariable Long id) {
        return ApiResponse.ok(challanService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<ChallanResponse> create(@Valid @RequestBody ChallanRequest request,
                                                 @AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(challanService.create(request, principal.getUser()));
    }

    @PostMapping("/{id}/confirm")
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<ChallanResponse> confirm(@PathVariable Long id) {
        return ApiResponse.ok(challanService.confirm(id));
    }

    @PostMapping("/{id}/cancel")
    @PreAuthorize("hasAnyRole('ADMIN','SALES')")
    public ApiResponse<ChallanResponse> cancel(@PathVariable Long id) {
        return ApiResponse.ok(challanService.cancel(id));
    }
}
