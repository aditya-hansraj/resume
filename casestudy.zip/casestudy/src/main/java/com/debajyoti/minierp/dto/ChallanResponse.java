package com.debajyoti.minierp.dto;

import com.debajyoti.minierp.entity.ChallanStatus;

import java.time.LocalDateTime;
import java.util.List;

public record ChallanResponse(
        Long id,
        String challanNumber,
        Long customerId,
        String customerName,
        ChallanStatus status,
        Integer totalQuantity,
        List<ChallanItemResponse> items,
        String createdByName,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
