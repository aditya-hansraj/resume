package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.ChallanItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChallanItemRepository extends JpaRepository<ChallanItem, Long> {
    List<ChallanItem> findByChallanId(Long challanId);
}
