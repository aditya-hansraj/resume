package com.debajyoti.minierp.dto;

public class ApiResponse<T> {

    private boolean success;
    private T data;
    private PageMeta meta;
    private String message;
    private Object details;

    public ApiResponse() {
    }

    private ApiResponse(boolean success, T data, PageMeta meta, String message, Object details) {
        this.success = success;
        this.data = data;
        this.meta = meta;
        this.message = message;
        this.details = details;
    }

    public static <T> ApiResponse<T> ok(T data) {
        return new ApiResponse<>(true, data, null, null, null);
    }

    public static <T> ApiResponse<T> ok(T data, PageMeta meta) {
        return new ApiResponse<>(true, data, meta, null, null);
    }

    public static <T> ApiResponse<T> error(String message, Object details) {
        return new ApiResponse<>(false, null, null, message, details);
    }

    public boolean isSuccess() { return success; }
    public void setSuccess(boolean success) { this.success = success; }

    public T getData() { return data; }
    public void setData(T data) { this.data = data; }

    public PageMeta getMeta() { return meta; }
    public void setMeta(PageMeta meta) { this.meta = meta; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Object getDetails() { return details; }
    public void setDetails(Object details) { this.details = details; }
}
