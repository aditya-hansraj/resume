package com.debajyoti.minierp.entity;

public enum MovementType {
    IN, OUT
}
