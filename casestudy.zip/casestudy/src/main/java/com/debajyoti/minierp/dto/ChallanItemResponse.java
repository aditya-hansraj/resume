package com.debajyoti.minierp.dto;

import java.math.BigDecimal;

public record ChallanItemResponse(
        Long productId,
        String productName,
        String sku,
        BigDecimal unitPrice,
        Integer quantity
) {
}
