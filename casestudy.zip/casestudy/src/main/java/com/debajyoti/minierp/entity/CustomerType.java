package com.debajyoti.minierp.entity;

public enum CustomerType {
    RETAIL, WHOLESALE, DISTRIBUTOR
}
