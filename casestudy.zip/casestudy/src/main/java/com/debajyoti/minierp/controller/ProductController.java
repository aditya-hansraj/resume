package com.debajyoti.minierp.controller;

import com.debajyoti.minierp.dto.ApiResponse;
import com.debajyoti.minierp.dto.PageMeta;
import com.debajyoti.minierp.dto.ProductRequest;
import com.debajyoti.minierp.dto.ProductResponse;
import com.debajyoti.minierp.dto.StockMovementRequest;
import com.debajyoti.minierp.dto.StockMovementResponse;
import com.debajyoti.minierp.security.UserPrincipal;
import com.debajyoti.minierp.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    private final ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    public ApiResponse<?> list(@RequestParam(required = false) String search,
                                @RequestParam(required = false) String category,
                                @RequestParam(defaultValue = "false") boolean lowStockOnly,
                                @RequestParam(defaultValue = "0") int page,
                                @RequestParam(defaultValue = "20") int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<ProductResponse> result = productService.list(search, category, lowStockOnly, pageable);
        PageMeta meta = new PageMeta(result.getNumber(), result.getSize(), result.getTotalElements(), result.getTotalPages());
        return ApiResponse.ok(result.getContent(), meta);
    }

    @GetMapping("/{id}")
    public ApiResponse<ProductResponse> getById(@PathVariable Long id) {
        return ApiResponse.ok(productService.getById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ApiResponse<ProductResponse> create(@Valid @RequestBody ProductRequest request) {
        return ApiResponse.ok(productService.create(request));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ApiResponse<ProductResponse> update(@PathVariable Long id, @Valid @RequestBody ProductRequest request) {
        return ApiResponse.ok(productService.update(id, request));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ApiResponse<Void> delete(@PathVariable Long id) {
        productService.delete(id);
        return ApiResponse.ok(null);
    }

    @PostMapping("/{id}/stock-movements")
    @PreAuthorize("hasAnyRole('ADMIN','WAREHOUSE')")
    public ApiResponse<StockMovementResponse> addStockMovement(@PathVariable Long id,
                                                                 @Valid @RequestBody StockMovementRequest request,
                                                                 @AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(productService.addStockMovement(id, request, principal.getUser()));
    }
}
