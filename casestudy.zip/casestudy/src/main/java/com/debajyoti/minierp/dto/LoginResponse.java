package com.debajyoti.minierp.dto;

public record LoginResponse(String token, UserDto user) {
}
