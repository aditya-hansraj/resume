package com.debajyoti.minierp.dto;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public record ProductResponse(
        Long id,
        String name,
        String sku,
        String category,
        BigDecimal unitPrice,
        Integer currentStock,
        Integer minStockAlert,
        String location,
        LocalDateTime createdAt,
        LocalDateTime updatedAt
) {
}
