package com.debajyoti.minierp.repository;

import com.debajyoti.minierp.entity.Challan;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface ChallanRepository extends JpaRepository<Challan, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select c from Challan c where c.id = :id")
    Optional<Challan> findByIdForUpdate(@Param("id") Long id);
}
