package com.debajyoti.minierp.dto;

import jakarta.validation.constraints.NotBlank;

import java.time.LocalDate;

public record FollowupRequest(
        @NotBlank String note,
        LocalDate followUpDate
) {
}
