package com.debajyoti.minierp.controller;

import com.debajyoti.minierp.dto.ApiResponse;
import com.debajyoti.minierp.dto.LoginRequest;
import com.debajyoti.minierp.dto.LoginResponse;
import com.debajyoti.minierp.dto.UserDto;
import com.debajyoti.minierp.security.UserPrincipal;
import com.debajyoti.minierp.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @PostMapping("/login")
    public ApiResponse<LoginResponse> login(@Valid @RequestBody LoginRequest request) {
        return ApiResponse.ok(authService.login(request));
    }

    @GetMapping("/me")
    public ApiResponse<UserDto> me(@AuthenticationPrincipal UserPrincipal principal) {
        return ApiResponse.ok(authService.toDto(principal.getUser()));
    }
}
