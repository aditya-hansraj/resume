package com.debajyoti.minierp.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.math.BigDecimal;

public record ProductRequest(
        @NotBlank String name,
        @NotBlank String sku,
        String category,
        @NotNull @DecimalMin(value = "0.0", inclusive = true) BigDecimal unitPrice,
        @NotNull @PositiveOrZero Integer currentStock,
        @NotNull @PositiveOrZero Integer minStockAlert,
        String location
) {
}
