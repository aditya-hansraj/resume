package com.debajyoti.minierp.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.List;

public record ChallanRequest(
        @NotNull Long customerId,
        @NotEmpty @Valid List<ChallanItemRequest> items
) {
}
