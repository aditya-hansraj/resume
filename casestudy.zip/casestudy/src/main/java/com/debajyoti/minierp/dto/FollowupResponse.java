package com.debajyoti.minierp.dto;

import java.time.LocalDate;
import java.time.LocalDateTime;

public record FollowupResponse(
        Long id,
        String note,
        LocalDate followUpDate,
        String createdByName,
        LocalDateTime createdAt
) {
}
