package com.debajyoti.minierp.dto;

public record PageMeta(int page, int size, long totalElements, int totalPages) {
}
