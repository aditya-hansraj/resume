-- Mini ERP + CRM Operations Portal - initial schema

CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_users_email UNIQUE (email),
    CONSTRAINT chk_users_role CHECK (role IN ('ADMIN','SALES','WAREHOUSE','ACCOUNTS'))
) ENGINE=InnoDB;

CREATE TABLE customers (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    email VARCHAR(150),
    business_name VARCHAR(200),
    gst_number VARCHAR(30),
    customer_type VARCHAR(20) NOT NULL,
    address VARCHAR(500),
    status VARCHAR(20) NOT NULL,
    follow_up_date DATE,
    notes VARCHAR(2000),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_customers_type CHECK (customer_type IN ('RETAIL','WHOLESALE','DISTRIBUTOR')),
    CONSTRAINT chk_customers_status CHECK (status IN ('LEAD','ACTIVE','INACTIVE'))
) ENGINE=InnoDB;

CREATE INDEX idx_customers_mobile ON customers (mobile);
CREATE INDEX idx_customers_business_name ON customers (business_name);
CREATE INDEX idx_customers_status ON customers (status);
CREATE INDEX idx_customers_email ON customers (email);

CREATE TABLE customer_followups (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    customer_id BIGINT NOT NULL,
    note VARCHAR(2000) NOT NULL,
    follow_up_date DATE,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_followup_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
    CONSTRAINT fk_followup_user FOREIGN KEY (created_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE INDEX idx_followups_customer_id ON customer_followups (customer_id);

CREATE TABLE products (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    sku VARCHAR(60) NOT NULL,
    category VARCHAR(100),
    unit_price DECIMAL(10,2) NOT NULL,
    current_stock INT NOT NULL DEFAULT 0,
    min_stock_alert INT NOT NULL DEFAULT 0,
    location VARCHAR(150),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_products_sku UNIQUE (sku),
    CONSTRAINT chk_products_stock_nonneg CHECK (current_stock >= 0)
) ENGINE=InnoDB;

CREATE INDEX idx_products_category ON products (category);

CREATE TABLE stock_movements (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    product_id BIGINT NOT NULL,
    quantity INT NOT NULL,
    movement_type VARCHAR(10) NOT NULL,
    reason VARCHAR(500),
    created_by BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_movement_product FOREIGN KEY (product_id) REFERENCES products (id),
    CONSTRAINT fk_movement_user FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT chk_movement_type CHECK (movement_type IN ('IN','OUT'))
) ENGINE=InnoDB;

CREATE INDEX idx_movements_product_id ON stock_movements (product_id);

CREATE TABLE challans (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    challan_number VARCHAR(40) NOT NULL,
    customer_id BIGINT NOT NULL,
    status VARCHAR(20) NOT NULL,
    total_quantity INT NOT NULL DEFAULT 0,
    created_by BIGINT NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT uq_challans_number UNIQUE (challan_number),
    CONSTRAINT fk_challan_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
    CONSTRAINT fk_challan_user FOREIGN KEY (created_by) REFERENCES users (id),
    CONSTRAINT chk_challan_status CHECK (status IN ('DRAFT','CONFIRMED','CANCELLED'))
) ENGINE=InnoDB;

CREATE INDEX idx_challans_status ON challans (status);
CREATE INDEX idx_challans_customer_id ON challans (customer_id);

CREATE TABLE challan_items (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    challan_id BIGINT NOT NULL,
    product_id BIGINT NOT NULL,
    product_name_snapshot VARCHAR(200) NOT NULL,
    sku_snapshot VARCHAR(60) NOT NULL,
    unit_price_snapshot DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    CONSTRAINT fk_item_challan FOREIGN KEY (challan_id) REFERENCES challans (id),
    CONSTRAINT fk_item_product FOREIGN KEY (product_id) REFERENCES products (id)
) ENGINE=InnoDB;

CREATE INDEX idx_challan_items_challan_id ON challan_items (challan_id);
CREATE INDEX idx_challan_items_product_id ON challan_items (product_id);

-- Atomic per-year counter used to generate challan numbers without relying on
-- COUNT(*) (which is race-prone under concurrent inserts). See ChallanService.
CREATE TABLE challan_counter (
    year INT PRIMARY KEY,
    last_value INT NOT NULL
) ENGINE=InnoDB;
