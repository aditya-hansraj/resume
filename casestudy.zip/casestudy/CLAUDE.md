# CLAUDE.md — handoff notes for any AI/engineer picking this up

This file exists so another model or engineer can continue this project without
re-deriving context. It is analysis/handoff documentation, not part of the
submission deliverables themselves (README.md is the actual submission doc).

## What this project is

A take-home case study: "Mini ERP + CRM Operations Portal" for a wholesale
distribution company. Built to a detailed spec (two source PDFs: a short generic
case-study brief, and a much more detailed "build prompt" that overrides it —
Java/Spring Boot stack, not the Node.js stack the generic brief mentioned).
Candidate name baked into package/README: Debajyoti. Base package
`com.debajyoti.minierp`.

Full run instructions are in `README.md` ("Running locally — with Docker" and
"— without Docker" sections). Don't duplicate them here; read that file for the
actual how-to-run steps and seeded credentials.

## Current state — what's done vs. unverified

Everything listed in the spec has been written: Flyway schema (`V1__init.sql`),
JPA entities, Spring Security + JWT, customer/product/challan modules with the
required business logic, plain HTML/CSS/JS frontend (6 pages), Dockerfile +
docker-compose, Postman collection, `.env.example`, README, and a 12-commit
incremental git history.

**Critical caveat: `./mvnw clean package` has never actually been run.** The
sandbox this was built in had no JDK 17 (only a JRE 11), no `mvn` binary, no
root access to install packages (`apt-get`/`sudo` both fail — no
`lock-frontend` permission, `no new privileges` blocks sudo), and outbound
network was allowlisted to the point that even `download.java.net` and
`api.adoptium.net` returned `403 blocked-by-allowlist`. So there was no way to
install a JDK 17 + Maven and no way to compile.

What was done instead: every Java file was hand-reviewed for import correctness,
Spring Boot 3.2.5 / Spring Security 6 / Jakarta Validation / jjwt 0.11.5 API
usage, and consistent field/method names across entity ↔ DTO ↔ repository ↔
service layers. All 8 frontend `.js` files pass `node --check` (syntax only, not
logic). The Postman JSON was validated with `json.load()`.

**If you're picking this up: run `./mvnw clean package -DskipTests` (or
`docker compose up --build`) first, before doing anything else.** Treat this as
an unverified build until that succeeds. If it doesn't compile, the likely
failure points are listed below.

## Likely first-compile-attempt trouble spots

These weren't wrong as far as manual review could tell, but they're the
highest-risk spots because they depend on exact framework API shape rather than
plain Java:

- `ProductRepository` — has custom `@Lock(LockModeType.PESSIMISTIC_WRITE)`
  query methods (`findAllByIdForUpdateOrderByIdAsc`, used from
  `ChallanService.confirm`/`cancel`). Double-check the JPQL `@Query` annotation
  syntax and that `ORDER BY` inside a locked query is accepted by your
  Hibernate/MySQL combo — some dialects complain about `ORDER BY` + pessimistic
  lock together.
- `ChallanRepository.findByIdForUpdate` — same lock pattern on a single-row
  fetch by id.
- `ChallanService.nextChallanNumber()` — raw `JdbcTemplate` + `LAST_INSERT_ID()`
  trick for the atomic counter. This depends on being inside the same
  transaction as the rest of `create()`; if Spring's proxy-based
  `@Transactional` isn't applying (e.g. self-invocation from another method in
  the same class bypassing the proxy), this could silently run in autocommit
  mode. Not currently an issue since `create()` is called externally, but keep
  an eye on it if you refactor.
- `SecurityConfig` — Spring Security 6.x moved to lambda-DSL
  (`http.authorizeHttpRequests(auth -> ...)`), not the deprecated fluent
  `.antMatchers()` style. Confirm the version actually used matches what's
  imported.
- `GlobalExceptionHandler` (`@RestControllerAdvice`) — confirm
  `MethodArgumentNotValidException` handler signature matches what Spring Boot
  3.2 expects, and that `DataIntegrityViolationException` is the right
  exception type surfaced by Hibernate for unique-constraint violations on
  MySQL (it usually is, via `ConstraintViolationException` wrapped by Spring's
  translation layer, but this is JDBC-driver-dependent).
- `jjwt` 0.11.5 API — `Jwts.builder()...signWith(key)` vs newer 0.12.x fluent
  API differ. Confirm `JwtService` uses the 0.11.x method signatures
  consistently (this version was deliberately pinned in `pom.xml`).

## Environment / infra notes

- `application.yml` is 100% env-var driven with sane local defaults — see the
  file itself, it's short. `.env.example` documents what docker-compose reads.
- MySQL: `current_stock >= 0` is a CHECK constraint in `V1__init.sql` *and*
  re-validated in `ProductService`/`ChallanService` before any decrement —
  belt-and-suspenders because CHECK constraint enforcement historically varies
  across MySQL versions/storage engines.
- Frontend has zero build step by design (spec requirement) — plain
  `<script>` tags, no `type="module"`, so `login.html` etc. can be
  double-clicked and opened via `file://`. This is why CORS in
  `SecurityConfig` is permissive and the JWT lives in `localStorage` rather
  than an httpOnly cookie. Don't "fix" this to be more secure without
  re-reading the spec — it's an intentional tradeoff documented in the README.

## Filesystem quirk discovered while building this (informational only)

The sandbox's mounted filesystem for this project directory does **not support
`unlink`** (delete) at all — plain `rm`, cross-directory `mv` (which falls back
to copy+unlink on failure), and git's internal lock-file cleanup (`unlink()` on
`.git/index.lock` etc.) all fail with "Operation not permitted." Same-directory
`rename()` (e.g. `mv old new` within one directory) does work. This caused some
stray debug files (`foo/`, `.gitkeep_test`) and stale `.git/*.lock` files to
accumulate during the original build session; they were cleaned up afterward
via the `allow_cowork_file_delete` tool + same-directory renames. Mentioning
this only so a future session isn't confused if `rm -rf` mysteriously fails
again in a similar sandboxed environment — it's an environment limitation, not
a project bug. Not relevant once this repo is cloned onto a normal machine.

## Suggested next steps for whoever continues this

1. Run `./mvnw clean package -DskipTests` on a real machine with JDK 17 +
   internet access. Fix whatever doesn't compile — check the "likely trouble
   spots" list above first.
2. Run `docker compose up --build` and smoke-test the full flow: log in as
   each role, create a customer, add a product, create a DRAFT challan,
   confirm it (watch stock decrement), try to over-confirm another challan
   against the same product (expect a clean 400), cancel a CONFIRMED challan
   (watch stock reverse).
3. Import `postman/minierp.postman_collection.json` and run it end-to-end.
4. Only after the above is green: consider the bonus items called out as
   skipped in the README (AWS/Terraform deployment, automated tests, GitHub
   Actions, PDF export, S3 image upload) if there's time left before
   submission.
