# Mini ERP + CRM Operations Portal

A small internal-tools case study: customer CRM, product/inventory tracking, and a
sales-challan (delivery note) workflow with atomic stock reservation. Built as a
take-home exercise by Debajyoti.

## Architecture

- **Backend**: Java 17, Spring Boot 3.2 (web, data-jpa, security, validation), MySQL 8
  via Flyway migrations, JWT auth (jjwt 0.11.5). Layered as
  `controller -> service -> repository -> entity`, with `dto`, `exception`, `security`,
  `config` as cross-cutting packages. DTOs (mostly Java records) are the only things
  that cross the controller boundary — JPA entities are never serialized directly.
- **Frontend**: plain HTML/CSS/vanilla JS, no framework, no build step, no ES modules.
  Lives in `frontend/` and is served as a static docroot (by nginx in Docker, or opened
  directly via `file://` for quick local checks — that's why CORS is permissive and
  JWT lives in `localStorage` rather than a cookie).
- **API shape**: every response is `{ success, data, meta, message, details }`. List
  endpoints populate `meta` with `{ page, size, totalElements, totalPages }`.

## Data model

`users`, `customers`, `customer_followups`, `products`, `stock_movements`,
`challans`, `challan_items`, `challan_counter` — see
`src/main/resources/db/migration/V1__init.sql` for the full schema, including the
`CHECK (current_stock >= 0)` constraint (also re-validated in the service layer before
any decrement, since not every DB enforces CHECK the same way).

## Running locally — with Docker (recommended)

```
cp .env.example .env      # adjust values if needed
docker compose up --build
```

- Frontend: http://localhost:8080
- Backend API: http://localhost:8081/api
- MySQL: localhost:3306

`docker-compose.yml` waits for MySQL's healthcheck before starting the backend, and
the backend runs Flyway migrations automatically on boot.

## Running locally — without Docker

1. Start a local MySQL 8 instance and create a `minierp` database.
2. Export env vars (or rely on the defaults baked into `application.yml`):
   `DB_URL`, `DB_USER`, `DB_PASSWORD`, `JWT_SECRET`, `JWT_EXPIRY_MS`, `SERVER_PORT`.
3. `./mvnw spring-boot:run` — Flyway runs the migrations on startup, and a
   `CommandLineRunner` (`DataSeeder`) seeds the four demo users the first time the
   `users` table is empty.
4. Open `frontend/login.html` directly in a browser (`file://...`), or serve the
   `frontend/` folder with any static file server. `js/api.js` points at
   `http://localhost:8081/api`.

## Environment variables

All backend config is env-var driven with safe local defaults (see `application.yml`).
`.env.example` documents every variable docker-compose reads: MySQL credentials/port,
`DB_URL`/`DB_USER`/`DB_PASSWORD` for the backend datasource, `JWT_SECRET`/`JWT_EXPIRY_MS`,
and the host ports for the backend and nginx-served frontend.

## Test credentials (seeded on first boot)

| Role      | Email                     | Password       |
|-----------|---------------------------|----------------|
| ADMIN     | admin@minierp.com         | Password123!   |
| SALES     | sales@minierp.com         | Password123!   |
| WAREHOUSE | warehouse@minierp.com     | Password123!   |
| ACCOUNTS  | accounts@minierp.com      | Password123!   |

Seeded via `DataSeeder` (a `CommandLineRunner`) using the real injected
`PasswordEncoder` at startup, rather than a hand-typed bcrypt hash in a Flyway
migration — a hash written by hand in this environment (no way to run the app to
verify it) risks a typo that silently locks every seed account out, whereas
`passwordEncoder.encode(...)` is guaranteed correct by construction.

## Role matrix

| Module              | ADMIN | SALES | WAREHOUSE | ACCOUNTS |
|---------------------|:-----:|:-----:|:---------:|:--------:|
| Customers — read     | Y | Y | Y | Y |
| Customers — write     | Y | Y | – | – |
| Products — read       | Y | Y | Y | Y |
| Products — write/stock | Y | – | Y | – |
| Challans — read       | Y | Y | Y | Y |
| Challans — write/confirm/cancel | Y | Y | – | – |

Reads are open to every authenticated role by design: WAREHOUSE needs to see
CONFIRMED challans to know what to physically ship, and ACCOUNTS needs visibility
into customers/products/challans for billing and reconciliation, even though neither
role can mutate that data.

## Core business logic worth reading

- **Challan numbering** (`ChallanService.nextChallanNumber`): uses
  `INSERT INTO challan_counter ... ON DUPLICATE KEY UPDATE last_value = LAST_INSERT_ID(last_value + 1)`
  inside the same `@Transactional` method that creates the challan, instead of
  `COUNT(*)` — `COUNT(*)` is race-prone under concurrent writes (two transactions can
  read the same count before either commits), producing duplicate challan numbers.
- **Challan confirm** (`ChallanService.confirm`): locks the challan row
  (`PESSIMISTIC_WRITE`) so concurrent confirm calls on the same challan serialize,
  verifies it's still `DRAFT`, then locks every distinct product referenced by the
  challan **in ascending id order in a single query** — this fixed lock ordering is
  what prevents deadlocks against other transactions (e.g. another challan confirming
  overlapping products) that would otherwise lock the same rows in a different order.
  All shortages are collected before any exception is thrown, so the error message
  lists every short product in one shot instead of failing fast on the first one.
- **Challan cancel**: `DRAFT -> CANCELLED` is a direct status flip with no stock
  impact. `CONFIRMED -> CANCELLED` reverses the stock decrement (IN movement per line,
  stock incremented back). This reversal behavior is an assumption — the original
  spec didn't define what cancelling an already-confirmed challan should do.

## Known limitations / assumptions

- Cancel-after-confirm stock reversal is an assumption (see above); a real system
  might instead forbid cancelling a CONFIRMED challan and require a separate
  "return" workflow.
- Pagination defaults to page size 20 across all list endpoints — an arbitrary but
  reasonable default for an internal ops tool, not driven by a stated requirement.
- Password policy is minimal (no complexity/length enforcement beyond the seed
  example) — out of scope for a take-home.
- No rate limiting or lockout on `/api/auth/login`.
- CORS is fully permissive (`*` origins, all methods/headers) — acceptable for local
  dev / this exercise, not something to ship to production as-is.
- No refresh tokens — JWT expiry only (`JWT_EXPIRY_MS`, default 24h); users simply
  log in again after expiry.
- No automated test suite — given the time box, effort went into the concurrency-
  sensitive challan logic and manual code review instead (see below).
- AWS/Terraform deployment was explicitly called out as a bonus, not a requirement,
  and was skipped due to time constraints — the Docker Compose setup is the intended
  deliverable for "runnable locally."

## A note on the Maven build

This was developed in a sandboxed environment with no internet access and no JDK 17
or Maven binary installed, so `./mvnw clean package` could not actually be executed
here. Every Java file was instead hand-reviewed for compile correctness (imports,
Spring Boot 3.2 / Spring Security 6 / Jakarta EE / jjwt 0.11.5 API usage, and
matching field/method names across entities, DTOs, repositories, and services).
Please run `./mvnw clean package` (or `docker compose up --build`) in a normal
environment as the real build verification.

## Postman

`postman/minierp.postman_collection.json` covers every endpoint, including saved
example responses for a failed stock-movement (`OUT` exceeding current stock) and a
failed challan confirm (insufficient stock across one or more products), both
returning HTTP 400 with the `BusinessRuleException` message in `message`.
